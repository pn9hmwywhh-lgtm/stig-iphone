import Foundation

enum GPX {
    static func escape(_ value: String) -> String {
        value.replacingOccurrences(of: "&", with: "&amp;").replacingOccurrences(of: "<", with: "&lt;")
            .replacingOccurrences(of: ">", with: "&gt;").replacingOccurrences(of: "\"", with: "&quot;")
            .replacingOccurrences(of: "'", with: "&apos;")
    }

    static func export(_ tour: Tour) throws -> URL {
        let iso = ISO8601DateFormatter()
        iso.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        let groups = tour.segments.map { segment in
            "<trkseg>" + segment.map { point in
                let height = point.altitude.map { "<ele>\($0)</ele>" } ?? ""
                let time = point.timestampKnown ? "<time>\(iso.string(from: point.timestamp))</time>" : ""
                return "<trkpt lat=\"\(point.latitude)\" lon=\"\(point.longitude)\">\(height)\(time)</trkpt>"
            }.joined() + "</trkseg>"
        }.joined()
        let document = """
        <?xml version="1.0" encoding="UTF-8"?>
        <gpx version="1.1" creator="Stig iPhone" xmlns="http://www.topografix.com/GPX/1/1" xmlns:stig="urn:stig:track:1"><trk><name>\(escape(tour.title))</name><desc>\(escape(tour.notes))</desc><type>\(escape(tour.activity.rawValue))</type><extensions><stig:activeDuration>\(Int(tour.duration * 1_000))</stig:activeDuration></extensions>\(groups)</trk></gpx>
        """
        let root = FileManager.default.temporaryDirectory.appendingPathComponent("Stig-export", isDirectory: true)
        try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
        let name = tour.title.unicodeScalars.map { CharacterSet.alphanumerics.contains($0) ? String($0) : "-" }.joined()
        let url = root.appendingPathComponent("\(String(name.prefix(70)))-\(tour.id.uuidString.prefix(6)).gpx")
        try Data(document.utf8).write(to: url, options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
        return url
    }

    static func read(_ url: URL) throws -> Tour {
        let granted = url.startAccessingSecurityScopedResource()
        defer { if granted { url.stopAccessingSecurityScopedResource() } }
        let size = try url.resourceValues(forKeys: [.fileSizeKey]).fileSize ?? 0
        guard size <= 20 * 1_024 * 1_024 else { throw GPXError.invalid("Välj en GPX-fil under 20 MB.") }
        let data = try Data(contentsOf: url)
        let reader = Reader()
        let parser = XMLParser(data: data)
        parser.shouldProcessNamespaces = true
        parser.shouldResolveExternalEntities = false
        parser.delegate = reader
        guard parser.parse(), reader.validRoot, reader.points.count >= 2 else {
            throw GPXError.invalid(reader.failure ?? "Filen är inte en giltig GPX med minst två spårpunkter.")
        }
        guard !reader.demo else { throw GPXError.invalid("Det här är en syntetisk exempeltur. Den läggs inte till bland dina riktiga turer.") }
        var duration = 0.0
        for index in reader.points.indices.dropFirst() {
            let a = reader.points[index - 1], b = reader.points[index]
            if !b.segmentStart && a.timestampKnown && b.timestampKnown {
                duration += max(0, b.timestamp.timeIntervalSince(a.timestamp))
            }
        }
        if let supplied = reader.duration, supplied >= 0, supplied.isFinite, supplied <= 315_576_000 { duration = supplied }
        return Tour(name: reader.name.isEmpty ? url.deletingPathExtension().lastPathComponent : String(reader.name.prefix(120)),
            activity: Activity(rawValue: reader.activity) ?? .hiking,
            createdAt: reader.points.first(where: { $0.timestampKnown })?.timestamp ?? Date(), duration: duration,
            notes: String(reader.notes.prefix(2_000)), points: reader.points, imported: true)
    }

    enum GPXError: LocalizedError {
        case invalid(String)
        var errorDescription: String? { if case .invalid(let message) = self { return message }; return nil }
    }

    private final class Reader: NSObject, XMLParserDelegate {
        var validRoot = false, demo = false
        var points: [TrackPoint] = []
        var name = "", notes = "", activity = "", buffer = ""
        var duration: Double?, failure: String?
        private var path: [String] = []
        private var firstInSegment = true
        private var current: TrackPoint?
        private let iso = ISO8601DateFormatter()
        private let fractionalISO: ISO8601DateFormatter = {
            let value = ISO8601DateFormatter(); value.formatOptions = [.withInternetDateTime, .withFractionalSeconds]; return value
        }()

        func parser(_ parser: XMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName: String?, attributes: [String: String]) {
            path.append(elementName); buffer = ""
            if path.count == 1 { validRoot = elementName == "gpx" }
            if ["trkseg", "rte", "trk"].contains(elementName) { firstInSegment = true }
            if ["trkpt", "rtept"].contains(elementName) {
                guard let latText = attributes["lat"], let lonText = attributes["lon"],
                      let latitude = Double(latText), let longitude = Double(lonText),
                      latitude.isFinite, longitude.isFinite, abs(latitude) <= 90, abs(longitude) <= 180 else {
                    failure = "GPX-filen innehåller en ogiltig position."; parser.abortParsing(); return
                }
                current = TrackPoint(latitude: latitude, longitude: longitude, accuracy: 0,
                    timestamp: Date(timeIntervalSince1970: 0), timestampKnown: false, segmentStart: firstInSegment)
            }
        }

        func parser(_ parser: XMLParser, foundCharacters string: String) { buffer += string }

        func parser(_ parser: XMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName: String?) {
            let text = buffer.trimmingCharacters(in: .whitespacesAndNewlines)
            if current != nil {
                if elementName == "ele", let value = Double(text), value.isFinite { current?.altitude = value }
                if elementName == "time", let date = fractionalISO.date(from: text) ?? iso.date(from: text) {
                    current?.timestamp = date; current?.timestampKnown = true
                }
                if ["trkpt", "rtept"].contains(elementName), let point = current {
                    points.append(point); current = nil; firstInSegment = false
                    if points.count > 100_000 { failure = "Välj en GPX-fil med färre än 100 000 punkter."; parser.abortParsing() }
                }
            } else if path.contains("trk") || path.contains("rte") {
                if elementName == "name", name.isEmpty { name = text }
                if elementName == "desc", notes.isEmpty { notes = text }
                if elementName == "type", activity.isEmpty { activity = text }
                if namespaceURI == "urn:stig:track:1" {
                    if elementName == "activeDuration", let milliseconds = Double(text) { duration = milliseconds / 1_000 }
                    if elementName == "demo" { demo = text == "true" }
                }
            }
            if !path.isEmpty { path.removeLast() }; buffer = ""
        }
    }
}
