#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p build
xcodebuild -version
simulator_id="$(xcrun simctl list devices available --json | python3 scripts/select-simulator.py)"
xcodebuild test \
  -project Stig.xcodeproj -scheme Stig -configuration Debug \
  -destination "platform=iOS Simulator,id=${simulator_id}" \
  -derivedDataPath build/simulator -resultBundlePath build/StigTests.xcresult \
  CODE_SIGNING_ALLOWED=NO \
  2>&1 | tee build/test.log
