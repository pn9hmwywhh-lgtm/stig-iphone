#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p build
xcodebuild build \
  -project Stig.xcodeproj -scheme Stig -configuration Release \
  -destination 'generic/platform=iOS' -derivedDataPath build/device \
  CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO CODE_SIGN_IDENTITY='' DEVELOPMENT_TEAM='' \
  2>&1 | tee build/build.log
app_path='build/device/Build/Products/Release-iphoneos/Stig.app'
test -f "${app_path}/Info.plist"
test -f "${app_path}/Stig"
lipo -verify_arch arm64 "${app_path}/Stig"
# SideStore signs on-device with the owner's own Apple account.
# No Apple password, paid certificate or provisioning secret goes into GitHub.
rm -rf build/ipa
mkdir -p build/ipa/Payload
ditto "$app_path" build/ipa/Payload/Stig.app
rm -f build/Stig.ipa
(cd build/ipa && zip -qr ../Stig.ipa Payload)
unzip -t build/Stig.ipa
