import Foundation

enum Activity: String, Codable, CaseIterable, Identifiable, Hashable {
    case hiking = "Vandring", skiing = "Skidåkning", snowboard = "Snowboard"
    case sup = "SUP", cycling = "Cykling", running = "Löpning"
    var id: String { rawValue }
    var symbol: String {
        switch self {
        case .hiking: return "figure.hiking"
        case .skiing: return "figure.skiing.crosscountry"
        case .snowboard: return "figure.snowboarding"
        case .sup: return "figure.surfing"
        case .cycling: return "figure.outdoor.cycle"
        case .running: return "figure.run"
        }
    }
}

struct TrackPoint: Codable, Equatable {
    var latitude: Double
    var longitude: Double
    var altitude: Double?
    var accuracy: Double
    var timestamp: Date
    var timestampKnown = true
    var segmentStart = false

    func distance(to b: TrackPoint) -> Double {
        let r = Double.pi / 180
        let latitudeTerm = pow(sin((b.latitude - latitude) * r / 2), 2)
        let longitudeTerm = pow(sin((b.longitude - longitude) * r / 2), 2)
        let x = latitudeTerm + cos(latitude * r) * cos(b.latitude * r) * longitudeTerm
        return 6_371_008.8 * 2 * atan2(sqrt(x), sqrt(max(0, 1 - x)))
    }
}

struct Tour: Identifiable, Codable, Equatable {
    var id = UUID()
    var name = ""
    var activity = Activity.hiking
    var createdAt = Date()
    var duration: TimeInterval = 0
    var notes = ""
    var points: [TrackPoint] = []
    var hasGaps = false
    var imported = false

    var stats: TourStats { TourStats(points: points) }
    var title: String { name.isEmpty ? "Din pågående tur" : name }
    var segments: [[TrackPoint]] {
        var result: [[TrackPoint]] = []
        for point in points {
            if result.isEmpty || point.segmentStart { result.append([]) }
            result[result.count - 1].append(point)
        }
        return result
    }
}

struct HeightSample: Identifiable {
    var id: Int
    var kilometers: Double
    var altitude: Double
    var segment: Int
}

struct SpeedWindow: Equatable {
    var kilometersPerHour: Double
    var startIndex: Int
    var endIndex: Int
    var markerIndex: Int { (startIndex + endIndex) / 2 }
}

enum SpeedMeasurement {
    /// Highest GPS path average over at least five seconds, within one segment.
    static func maximum(in points: [TrackPoint]) -> SpeedWindow? {
        var result: SpeedWindow?
        var previous: TrackPoint?
        var window: [(time: Date, distance: Double, index: Int)] = []
        var start = 0, travelled = 0.0
        for (index, point) in points.enumerated() {
            guard point.timestampKnown, point.timestamp.timeIntervalSince1970.isFinite,
                  point.latitude.isFinite, point.longitude.isFinite,
                  abs(point.latitude) <= 90, abs(point.longitude) <= 180,
                  point.accuracy.isFinite, point.accuracy >= 0, point.accuracy <= 50 else {
                previous = nil; window.removeAll(keepingCapacity: true); start = 0; travelled = 0
                continue
            }
            let elapsed = previous.map { point.timestamp.timeIntervalSince($0.timestamp) } ?? 0
            let meters = previous.map { $0.distance(to: point) } ?? 0
            if previous == nil || point.segmentStart || elapsed <= 0 || elapsed > 15 || meters / elapsed > 45 {
                window.removeAll(keepingCapacity: true); start = 0; travelled = 0
            } else { travelled += meters }
            window.append((point.timestamp, travelled, index))
            while start + 1 < window.count, point.timestamp.timeIntervalSince(window[start + 1].time) >= 5 { start += 1 }
            let duration = point.timestamp.timeIntervalSince(window[start].time)
            if duration >= 5 {
                let speed = (travelled - window[start].distance) / duration * 3.6
                if result == nil || speed > result!.kilometersPerHour {
                    result = SpeedWindow(kilometersPerHour: speed, startIndex: window[start].index, endIndex: index)
                }
            }
            previous = point
        }
        return result
    }
}

struct TourStats {
    var distance = 0.0
    var ascent: Double?
    var descent: Double?
    var maximum: Double?
    var minimum: Double?
    var profile: [HeightSample] = []
    var elevationRange: Double?
    var maximumSpeedWindow: SpeedWindow?
    var maximumSpeed: Double? { maximumSpeedWindow?.kilometersPerHour }

    init(points: [TrackPoint]) {
        var previous: TrackPoint?
        var smooth: Double?, anchor: Double?
        var up = 0.0, down = 0.0, heightCount = 0, series = 0
        for (index, point) in points.enumerated() {
            if let last = previous, !point.segmentStart { distance += last.distance(to: point) }
            if point.segmentStart { smooth = nil; anchor = nil; series += 1 }
            if let altitude = point.altitude, altitude.isFinite {
                let value = smooth.map { $0 * 0.65 + altitude * 0.35 } ?? altitude
                smooth = value
                maximum = max(maximum ?? value, value)
                minimum = min(minimum ?? value, value)
                heightCount += 1
                if anchor == nil { anchor = value }
                if let base = anchor, abs(value - base) >= 4 {
                    if value > base { up += value - base } else { down += base - value }
                    anchor = value
                }
                profile.append(HeightSample(id: index, kilometers: distance / 1_000, altitude: value, segment: series))
            } else { smooth = nil; anchor = nil; series += 1 }
            previous = point
        }
        if heightCount > 1 {
            ascent = up; descent = down
            if let maximum, let minimum { elevationRange = maximum - minimum }
        }
        maximumSpeedWindow = SpeedMeasurement.maximum(in: points)
    }
}

enum PointFilter {
    static func accept(_ point: TrackPoint, after previous: TrackPoint?, lastFix: Date?, newSegment: Bool) -> TrackPoint? {
        guard point.latitude.isFinite, point.longitude.isFinite,
              abs(point.latitude) <= 90, abs(point.longitude) <= 180,
              point.accuracy >= 0, point.accuracy <= 50 else { return nil }
        var result = point
        guard let previous else { result.segmentStart = true; return result }
        guard point.timestamp > previous.timestamp else { return nil }
        let gap = newSegment || point.timestamp.timeIntervalSince(lastFix ?? previous.timestamp) > 90
        if !gap {
            let distance = previous.distance(to: point)
            guard distance / point.timestamp.timeIntervalSince(previous.timestamp) <= 45 else { return nil }
            guard distance >= max(5, min(15, (point.accuracy + previous.accuracy) * 0.2)) else { return nil }
        }
        result.segmentStart = gap
        return result
    }
}

enum Display {
    static func number(_ value: Double?, digits: Int = 0) -> String {
        guard let value, value.isFinite else { return "—" }
        return value.formatted(.number.locale(Locale(identifier: "sv_SE")).precision(.fractionLength(digits)))
    }
    static func descent(_ value: Double?) -> String {
        guard let value else { return "—" }
        let rounded = value.rounded()
        return number(rounded == 0 ? 0 : -rounded)
    }
    static func clock(_ value: TimeInterval) -> String {
        let seconds = Int(max(0, value))
        return String(format: "%02d:%02d:%02d", seconds / 3600, (seconds / 60) % 60, seconds % 60)
    }
}

struct Archive: Codable {
    var schema = 1
    var tours: [Tour] = []
    var draft: Tour?
}
