# Installera Stig gratis med Windows och SideStore

Du behöver en iPhone med **iOS 17 eller senare**, en Windowsdator, en USB-kabel, Wi-Fi, ett kostnadsfritt Apple-konto och ett GitHub-konto. Datorn behövs för första installationen. Förnyelse kan därefter göras på iPhone via Wi-Fi. Ingen egen Mac eller App Store-publicering behövs.

**Paketet innehåller källkod, inte en färdig IPA.** GitHub-steget nedan bygger appfilen. När en grön byggning finns kan du gå vidare till installationen.

## 1. Skapa appfilen hos GitHub

Om GitHub ansluts i ChatGPT kan bygget förberedas och följas där. För att göra det själv:

1. Packa upp `Stig-iPhone-projekt.zip` i Windows.
2. Logga in på [GitHub](https://github.com/) och skapa ett nytt repo, exempelvis `stig-iphone`. Välj **Public**, så att standardbyggaren med macOS kan användas gratis. Bara projektets källkod behöver läggas upp.
3. Öppna mappen `Stig-iPhone` som du packade upp. Ladda upp **innehållet** till repots rot: `Stig`, `Tests`, `Stig.xcodeproj`, `scripts`, `.github`, `.gitignore` och dokumenten. Den nedladdade zip-filen ska inte laddas upp som enda fil. `Stig.xcodeproj` ska ligga direkt i repots rot.
4. Kontrollera att `.github/workflows/build-iphone.yml` finns i GitHub. Bekräfta uppladdningen med **Commit changes** på `main`.
5. Öppna **Actions → Bygg Stig för iPhone**. Aktivera Actions om GitHub frågar. Klicka **Run workflow** om bygget inte redan körs.
6. Vänta tills körningen är grön. Flödet kör först projektkontroller och modelltesterna på Mac, sedan byggs appen för riktig iPhone.
7. Öppna den gröna körningen och hämta artefakten **Stig-iPhone** längst ned. Packa upp den hämtade artefaktens zip. Där finns **Stig.ipa**.

Flödet körs bara för publika repo. Om jobbet visas som **Skipped** är repot sannolikt privat. Om körningen är röd finns ingen godkänd appfil: öppna det röda steget och spara feltexten eller artefakten `Stig-byggloggar` för felsökning. En IPA byggs först efter godkända tester.

Bygget behöver inte Apple-lösenord, telefonens lösenkod eller ett betalt utvecklarkonto. Du behöver inte bygga om varje vecka; veckoförnyelsen sköter signeringen av den redan installerade appen.

## 2. Förbered Windows och SideStore

Följ [SideStores aktuella förberedelser](https://docs.sidestore.io/docs/installation/prerequisites.html) och [installationsguide](https://docs.sidestore.io/docs/installation/install.html). De länkar till rätt nedladdningar.

1. Installera iTunes/Apple-komponenterna enligt guiden och **iloader** på Windows.
2. Installera **LocalDevVPN** på iPhone från länken i SideStores guide.
3. Anslut iPhone till datorn via USB, lås upp och godkänn att du litar på datorn.
4. Öppna iloader, logga själv in med ditt Apple-konto, välj telefonen och **Install SideStore (Stable)**.
5. På iPhone: godkänn utvecklarappen under **Inställningar → Allmänt → VPN och enhetshantering**. Aktivera **Utvecklarläge** under **Integritet och säkerhet** om det behövs och följ omstarten.
6. Anslut till Wi-Fi, aktivera LocalDevVPN och öppna SideStore. Logga in med samma Apple-konto som i iloader.
7. Förnya **SideStore självt först** under **My Apps** genom att trycka på dagräknaren. Gör detta innan du lägger till Stig.

## 3. Installera Stig på telefonen

1. Hämta samma GitHub-artefakt **Stig-iPhone** på iPhone via Safari, eller överför den från Windows. Om det är en zip: tryck på den i **Filer** för att packa upp och hitta `Stig.ipa`.
2. Med Wi-Fi och LocalDevVPN aktiverade, öppna **SideStore → My Apps → +** och välj `Stig.ipa`.
3. Vänta medan SideStore signerar och installerar appen. Stig visas därefter på hemskärmen.
4. Öppna Stig utomhus. Välj aktivitet och tryck **Starta tur**. Tillåt platsåtkomst när appen används och **Exakt plats**.
5. Vänta tills GPS har hittats, lås skärmen och gå en kort runda. Lås upp efter 10–15 minuter och kontrollera spåret, sparad tur och en GPX-export.

Om ett steg inte stämmer med den installerade SideStore-versionen, använd den officiella guiden ovan som aktuell anvisning. Appfilen ska vara IPA-filen, inte hela projektzippen eller GitHubs yttre artefaktzip.

## 4. Förnya utan veckovis datoranslutning

Gratis signering gäller i sju dagar. Innan tiden går ut: anslut iPhone till Wi-Fi, aktivera LocalDevVPN och öppna SideStore för att förnya **både SideStore och Stig**. Kontrollera att dagräknarna återställs. Automatisk bakgrundsförnyelse kan hjälpa, men kontrollera den före en tur.

Om SideStore hinner löpa ut eller parkopplingen slutar fungera kan Windows behövas igen. SideStores dokumentation nämner att parkopplingen kan behöva ersättas efter bland annat iOS-uppdatering eller återställning. Gratis Apple-konton tillåter ett begränsat antal installerade sideloadade appar; SideStore och Stig använder två platser.

## Behåll dina turer

Exportera viktiga turer som GPX. Vid uppdatering installerar du den nya IPA-filen genom samma SideStore och Apple-konto; behåll samma Bundle Identifier och radera inte Stig för att uppdatera. En avinstallation kan radera appens lokala turer. Turer från webbversionen flyttas med dess GPX-export och iPhone-appens **Mina turer → Importera GPX**.

## Källor, kontrollerade 24 november 2026

- [GitHubs standardbyggare och kostnadsfria publika repo](https://docs.github.com/en/actions/how-tos/write-workflows/choose-where-workflows-run/choose-the-runner-for-a-job)
- [SideStore: förberedelser](https://docs.sidestore.io/docs/installation/prerequisites.html)
- [SideStore: installation och parkoppling](https://docs.sidestore.io/docs/installation/install.html)
- [SideStore: förnyelse och begränsningar](https://docs.sidestore.io/docs/faq.html)
- [Apple: platsuppdateringar i bakgrunden](https://developer.apple.com/documentation/corelocation/handling-location-updates-in-the-background)
