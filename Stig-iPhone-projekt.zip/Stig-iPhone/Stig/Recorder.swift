import CoreLocation
import Combine
import UIKit

@MainActor
final class Recorder: NSObject, ObservableObject, CLLocationManagerDelegate {
    enum Phase: Equatable { case idle, waiting, recording, paused }
    @Published private(set) var phase = Phase.idle
    @Published private(set) var tours: [Tour] = []
    @Published private(set) var draft: Tour?
    @Published private(set) var now = Date()
    @Published private(set) var signal = "GPS aktiveras när du startar"
    @Published private(set) var latest: CLLocation?
    @Published private(set) var isSaving = false
    @Published var message: String?
    @Published private(set) var persistenceError: String?

    private let manager = CLLocationManager()
    private var backgroundSession: CLBackgroundActivitySession?
    private var disk: DiskStore?
    private var runningSince: Date?
    private var sessionRequestedAt = Date()
    private var lastFix: Date?
    private var newSegment = true
    private var lastPersist = Date.distantPast
    private var timer: AnyCancellable?
    private var loadFailed = false

    override init() {
        super.init()
        manager.delegate = self
        manager.desiredAccuracy = kCLLocationAccuracyBest
        manager.distanceFilter = 5
        manager.activityType = .fitness
        manager.pausesLocationUpdatesAutomatically = false
        manager.showsBackgroundLocationIndicator = true
        do {
            let storage = try DiskStore()
            disk = storage
            let saved = try storage.load()
            tours = saved.tours.sorted { $0.createdAt > $1.createdAt }
            if let pending = saved.draft {
                draft = pending
                phase = .paused
                signal = "Din tidigare tur har återställts och är pausad"
            }
        } catch {
            loadFailed = true
            persistenceError = "Sparade turer kunde inte läsas. Ingen befintlig fil har skrivits över."
        }
        timer = Timer.publish(every: 1, on: .main, in: .common).autoconnect().sink { [weak self] date in
            self?.now = date
            if self?.isActive == true { self?.checkpoint(force: false) }
        }
    }

    var duration: TimeInterval { (draft?.duration ?? 0) + (runningSince.map { Date().timeIntervalSince($0) } ?? 0) }
    var status: String {
        switch phase {
        case .idle: return "Redo för en ny tur"
        case .waiting: return "Söker GPS"
        case .recording: return "Spelar in · även med låst skärm"
        case .paused: return "Pausad"
        }
    }
    var isActive: Bool { phase == .recording || phase == .waiting }

    func start(activity: Activity) {
        guard !isSaving else { return }
        guard !loadFailed, disk != nil else {
            message = "Det går inte att spara turer just nu. Åtgärda lagringsfelet innan du spelar in."
            return
        }
        guard CLLocationManager.locationServicesEnabled() else { message = "Slå på Platstjänster i iPhones inställningar."; return }
        guard manager.authorizationStatus != .denied, manager.authorizationStatus != .restricted else {
            message = "Tillåt platsåtkomst för Stig under Inställningar och slå på Exakt plats."
            return
        }
        if draft == nil { draft = Tour(activity: activity) }
        phase = .waiting
        signal = "Väntar på en noggrann GPS-position"
        sessionRequestedAt = Date()
        newSegment = true
        lastFix = nil
        checkpoint(force: true)
        if manager.authorizationStatus == .notDetermined { manager.requestWhenInUseAuthorization() }
        else { beginLocationUpdates() }
    }

    private func beginLocationUpdates() {
        guard phase == .waiting else { return }
        if manager.accuracyAuthorization == .reducedAccuracy {
            manager.requestTemporaryFullAccuracyAuthorization(withPurposeKey: "HikeRecording") { [weak self] error in
                Task { @MainActor in
                    guard let self, self.phase == .waiting else { return }
                    if error != nil || self.manager.accuracyAuthorization == .reducedAccuracy {
                        self.pause()
                        self.message = "För att rita ditt spår behöver Stig Exakt plats. Tillåt det under Inställningar."
                    } else { self.enableUpdates() }
                }
            }
        } else { enableUpdates() }
    }

    private func enableUpdates() {
        guard phase == .waiting else { return }
        // Info.plist contains UIBackgroundModes = [location]. Start in foreground.
        // Keep the CLLocationManager alive for the entire explicitly started tour.
        guard UIApplication.shared.applicationState == .active else {
            pause(); message = "Öppna Stig för att starta bakgrundsinspelningen."; return
        }
        if backgroundSession == nil { backgroundSession = CLBackgroundActivitySession() }
        manager.allowsBackgroundLocationUpdates = true
        manager.startUpdatingLocation()
    }

    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        switch manager.authorizationStatus {
        case .authorizedAlways, .authorizedWhenInUse: beginLocationUpdates()
        case .denied, .restricted:
            if isActive { pause(); message = "Platsåtkomsten är avstängd. Turen har pausats." }
        default: break
        }
    }

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard isActive, draft != nil, !isSaving else { return }
        for location in locations.sorted(by: { $0.timestamp < $1.timestamp }) {
            guard location.timestamp >= sessionRequestedAt.addingTimeInterval(-5),
                  lastFix.map({ location.timestamp > $0 }) ?? true else { continue }
            signal = location.horizontalAccuracy >= 0 && location.horizontalAccuracy <= 50
                ? "GPS ±\(Int(location.horizontalAccuracy)) m"
                : "Svag GPS-signal – väntar på bättre position"
            let point = TrackPoint(latitude: location.coordinate.latitude, longitude: location.coordinate.longitude,
                altitude: location.verticalAccuracy >= 0 && location.verticalAccuracy <= 50 ? location.altitude : nil,
                accuracy: location.horizontalAccuracy, timestamp: location.timestamp)
            let previousFix = lastFix
            let accepted = PointFilter.accept(point, after: draft?.points.last, lastFix: previousFix, newSegment: newSegment)
            // Good stationary fixes keep signal time fresh without adding distance.
            if point.accuracy >= 0 && point.accuracy <= 50 { lastFix = point.timestamp }
            guard let accepted else { continue }
            latest = location
            if phase == .waiting { phase = .recording; runningSince = Date() }
            if let previousFix, point.timestamp.timeIntervalSince(previousFix) > 90 { draft?.hasGaps = true }
            draft?.points.append(accepted)
            newSegment = false
        }
        checkpoint(force: false)
    }

    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        if let error = error as? CLError, error.code == .denied {
            pause(); message = "GPS-åtkomst saknas. Kontrollera Stigs platsbehörighet i Inställningar."
        } else { signal = "GPS-signalen saknas just nu" }
    }

    func pause() {
        guard draft != nil else { return }
        draft?.duration = duration
        runningSince = nil
        manager.stopUpdatingLocation()
        manager.allowsBackgroundLocationUpdates = false
        backgroundSession?.invalidate()
        backgroundSession = nil
        phase = .paused
        signal = "Pausen räknas bort från din aktiva tid"
        checkpoint(force: true)
    }

    func checkpoint(force: Bool) {
        guard !loadFailed, !isSaving, let disk else { return }
        guard force || Date().timeIntervalSince(lastPersist) >= 5 else { return }
        var snapshot = draft
        snapshot?.duration = duration
        lastPersist = Date()
        disk.write(Archive(tours: tours, draft: snapshot)) { [weak self] error in
            if error != nil {
                self?.persistenceError = "Turen kunde inte sparas. Behåll appen öppen och exportera GPX som säkerhetskopia."
            }
        }
    }

    func save(name: String, notes: String) async -> Bool {
        guard !isSaving, var tour = draft, !tour.points.isEmpty, let disk else { return false }
        pause()
        tour.duration = draft?.duration ?? duration
        tour.name = name.trimmingCharacters(in: .whitespacesAndNewlines)
        if tour.name.isEmpty { tour.name = "\(tour.activity.rawValue) \(tour.createdAt.formatted(date: .abbreviated, time: .omitted))" }
        tour.notes = notes
        isSaving = true
        defer { isSaving = false }
        let updated = ([tour] + tours).sorted { $0.createdAt > $1.createdAt }
        do {
            // One atomic write commits the new tour and removes the draft together.
            try await disk.commit(Archive(tours: updated, draft: nil))
            tours = updated; draft = nil; phase = .idle; latest = nil
            signal = "GPS aktiveras när du startar"
            return true
        } catch { message = "Kunde inte spara turen. Exportera GPX som säkerhetskopia."; return false }
    }

    func discard() async {
        guard !isSaving, let disk else { return }
        pause(); isSaving = true
        defer { isSaving = false }
        do {
            try await disk.commit(Archive(tours: tours, draft: nil))
            draft = nil; phase = .idle; latest = nil; signal = "GPS aktiveras när du startar"
        } catch { message = "Inspelningen kunde inte tas bort." }
    }

    func importTour(_ tour: Tour) async {
        guard !isSaving, !loadFailed, let disk else { return }
        // Freeze the current draft snapshot while this archive transaction runs.
        var pending = draft; pending?.duration = duration
        let updated = ([tour] + tours).sorted { $0.createdAt > $1.createdAt }
        isSaving = true
        do { try await disk.commit(Archive(tours: updated, draft: pending)); tours = updated }
        catch { message = "GPX-turen kunde inte sparas." }
        isSaving = false
    }

    func deleteTour(id: UUID) async {
        guard !isSaving, !loadFailed, let disk else { return }
        var pending = draft; pending?.duration = duration
        let updated = tours.filter { $0.id != id }
        isSaving = true
        do { try await disk.commit(Archive(tours: updated, draft: pending)); tours = updated }
        catch { message = "Turen kunde inte tas bort." }
        isSaving = false
    }
}
