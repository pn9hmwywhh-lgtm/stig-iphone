"""Choose an installed iPhone simulator; never assume a model/OS version."""
import json
import sys

for runtime, devices in json.load(sys.stdin).get("devices", {}).items():
    if ".iOS-" not in runtime:
        continue
    for device in devices:
        if device.get("isAvailable") and device.get("name", "").startswith("iPhone"):
            print(device["udid"])
            sys.exit(0)
sys.exit("Ingen tillgänglig iPhone-simulator hittades på byggdatorn.")
