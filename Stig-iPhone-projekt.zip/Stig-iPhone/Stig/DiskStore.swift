import Foundation

/// Writes remain possible after the user locks the device during a recording.
/// iOS data protection still applies; files are inaccessible before first unlock.
final class DiskStore {
    private let queue = DispatchQueue(label: "se.stig.disk", qos: .utility)
    private let url: URL

    init() throws {
        let root = try FileManager.default.url(for: .applicationSupportDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
            .appendingPathComponent("Stig", isDirectory: true)
        try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true,
            attributes: [.protectionKey: FileProtectionType.completeUntilFirstUserAuthentication])
        url = root.appendingPathComponent("turer-v1.json")
    }

    func load() throws -> Archive {
        guard FileManager.default.fileExists(atPath: url.path) else { return Archive() }
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .millisecondsSince1970
        let archive = try decoder.decode(Archive.self, from: Data(contentsOf: url))
        guard archive.schema == 1 else { throw CocoaError(.fileReadCorruptFile) }
        return archive
    }

    func write(_ archive: Archive, completion: @escaping (Error?) -> Void) {
        queue.async {
            do {
                let encoder = JSONEncoder()
                encoder.dateEncodingStrategy = .millisecondsSince1970
                let data = try encoder.encode(archive)
                try data.write(to: self.url, options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
                DispatchQueue.main.async { completion(nil) }
            } catch { DispatchQueue.main.async { completion(error) } }
        }
    }

    func commit(_ archive: Archive) async throws {
        try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<Void, Error>) in
            write(archive) { error in
                if let error { continuation.resume(throwing: error) }
                else { continuation.resume() }
            }
        }
    }
}
