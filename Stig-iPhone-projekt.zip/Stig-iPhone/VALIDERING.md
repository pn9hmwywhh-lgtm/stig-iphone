# Kontroller och återstående provning

Kontrollerat 24 november 2026. Version 0.2.0.

| Kontroll | Resultat |
| --- | --- |
| Swift-syntax, sju appfiler och en testfil | Godkänd av Tree-sitter Swift. Detta är ingen typkontroll eller iOS-kompilering. |
| Xcode-projektets OpenStep-format | Inläst utan parserfel, app- och testmål samt objektreferenser kontrollerade. |
| Delat schema, Info.plist, appikon och källfilsreferenser | Godkända strukturella kontroller. |
| GitHub-workflow | Giltig YAML; manuellt startläge, standardrunner med macOS, spärr för privata repo, modellteststeg och IPA-artefakt konfigurerade. Inte kört hos GitHub ännu. |
| Bygg- och testskript | Bash-syntax godkänd. De kontrollerar simulator, Xcode-resultat, arm64-app och IPA-arkiv när de körs på macOS. |
| XCTest | 17 tester för distans, höjd, GPS-filter, maxhastighet, mätsträcka och GPX finns. Inte körda här. |
| Swift-typkontroll, iOS SDK, länkning och IPA | Inte utfört; Linux-miljön saknar Xcode och iOS SDK. Kräver första GitHub-körningen. |
| Signering och installation genom SideStore | Inte utfört; görs på ägarens iPhone med ägarens Apple-konto. |
| Låst skärm, GPS och batteriförbrukning | Inte verifierat på fysisk telefon. Måste provas efter installation. |

## Konfiguration för bakgrunden

`UIBackgroundModes` innehåller `location`. `Recorder` håller en `CLLocationManager` och en `CLBackgroundActivitySession` under den uttryckligen startade inspelningen. Inspelningen startar i förgrunden med When In Use-behörighet och Exakt plats. Paus och avslut stoppar platsuppdateringarna och invaliderar sessionen. Checkpoints görs från GPS-callbacken och skriver atomiskt med filskydd som tillåter skrivning efter låsning.

Konfiguration och syntaxkontroller visar avsikten, men bevisar inte att alla behörigheter, iOS-versioner och bakgrundstillstånd fungerar på en viss telefon.

## Efter en grön GitHub-körning

1. Kontrollera att simulatorns XCTest-steg är grönt och att artefakten innehåller en verklig `Stig.ipa`.
2. Installera via SideStore och starta en tur utomhus. Kontrollera att GPS får en noggrann position.
3. Lås skärmen i 10–15 minuter under förflyttning. Kontrollera därefter hela spåret och exportera GPX för att se om det finns luckor.
4. Pausa, förflytta dig och fortsätt. Förflyttningen under pausen ska inte räknas med. Avsluta och spara.
5. Spela in ett snowboardåk. Kontrollera negativa höjdmeter, fallhöjd, maxhastighet, markerad mätsträcka och knappen Visa toppfarten.
6. Prova nekad platsåtkomst, avstängd Exakt plats, växling till annan app och frånvaro av internet.
7. Öppna om Stig: en avbruten tur ska återställas pausad. Sparade turer ska finnas kvar.
8. Exportera/importera GPX och jämför segment, tid, aktivitet och höjd. Prova GPX utan tid/höjd: saknade värden ska förbli okända.
9. Förnya SideStore och Stig före sju dagar, öppna Stig och kontrollera att turerna finns kvar.

Svep inte bort Stig från appväxlaren under en pågående tur. Använd GPX som säkerhetskopia. Bakgrundsinspelning kan inte garanteras efter tvångsavslut eller systemavslut.
