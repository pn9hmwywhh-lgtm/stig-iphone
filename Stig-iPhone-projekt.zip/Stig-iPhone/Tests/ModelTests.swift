import XCTest
@testable import Stig

final class ModelTests: XCTestCase {
    private func point(_ latitude: Double, altitude: Double? = nil, seconds: Double = 0, accuracy: Double = 5, start: Bool = false) -> TrackPoint {
        TrackPoint(latitude: latitude, longitude: 17, altitude: altitude, accuracy: accuracy,
            timestamp: Date(timeIntervalSince1970: seconds), segmentStart: start)
    }

    func testDistanceAtSwedishLatitude() {
        XCTAssertEqual(point(62).distance(to: point(62.001)), 111.195, accuracy: 0.1)
    }
    func testPausesDoNotAddDistanceOrClimbing() {
        let points = [point(62, altitude: 100), point(62.001, altitude: 110),
            point(64, altitude: 900, start: true), point(64.001, altitude: 910)]
        let stats = TourStats(points: points)
        XCTAssertEqual(stats.distance, 222.39, accuracy: 1)
        XCTAssertLessThan(stats.ascent ?? 1_000, 20)
    }
    func testMissingAltitudeIsNotZero() {
        XCTAssertNil(TourStats(points: [point(62), point(62.001)]).ascent)
        XCTAssertEqual(TourStats(points: [point(62, altitude: 0), point(62.001, altitude: 0)]).ascent, 0)
    }
    func testAltitudeNoiseDoesNotAccumulate() {
        let points = (0..<100).map { point(62 + Double($0) / 10_000, altitude: $0 % 2 == 0 ? 98 : 102) }
        XCTAssertEqual(TourStats(points: points).ascent, 0)
    }
    func testAccuracyAndJumpFilters() {
        let first = point(62, seconds: 1)
        XCTAssertNil(PointFilter.accept(point(62.001, seconds: 2, accuracy: 140), after: first, lastFix: first.timestamp, newSegment: false))
        XCTAssertNil(PointFilter.accept(point(64, seconds: 2), after: first, lastFix: first.timestamp, newSegment: false))
    }
    func testSignalGapStartsSegment() {
        let first = point(62, seconds: 1)
        let next = PointFilter.accept(point(64, seconds: 100), after: first, lastFix: first.timestamp, newSegment: false)
        XCTAssertEqual(next?.segmentStart, true)
    }
    func testStationaryFixesDoNotBecomeSignalGap() {
        let first = point(62, seconds: 1)
        let next = PointFilter.accept(point(62.001, seconds: 140), after: first,
            lastFix: Date(timeIntervalSince1970: 139), newSegment: false)
        XCTAssertEqual(next?.segmentStart, false)
    }
    func testGPXRoundTripPreservesPausedTimeAndActivity() throws {
        let tour = Tour(name: "Tur & <test>", activity: .sup, duration: 45, notes: "Fint vatten", points: [
            point(62, altitude: nil, seconds: 1, start: true), point(62.001, altitude: 0, seconds: 61)
        ])
        let url = try GPX.export(tour)
        defer { try? FileManager.default.removeItem(at: url) }
        let restored = try GPX.read(url)
        XCTAssertEqual(restored.name, tour.name)
        XCTAssertEqual(restored.activity, .sup)
        XCTAssertEqual(restored.duration, 45)
        XCTAssertEqual(restored.notes, tour.notes)
        XCTAssertNil(restored.points[0].altitude)
        XCTAssertEqual(restored.points[1].altitude, 0)
    }
    private func speedPoints(_ speeds: [Double], interval: TimeInterval = 1) -> [TrackPoint] {
        var latitude = 62.0
        var points = [point(latitude)]
        for (index, speed) in speeds.enumerated() {
            latitude += speed / 3.6 * interval / 6_371_008.8 * 180 / .pi
            points.append(point(latitude, altitude: 1_000 - Double(index) * 10, seconds: Double(index + 1) * interval))
        }
        return points
    }
    func testSustainedSnowboardPeakAndMapWindow() throws {
        let points = speedPoints(Array(repeating: 36, count: 10) + Array(repeating: 72, count: 10))
        let stats = TourStats(points: points)
        let peak = try XCTUnwrap(stats.maximumSpeedWindow)
        XCTAssertEqual(peak.kilometersPerHour, 72, accuracy: 0.01)
        XCTAssertGreaterThanOrEqual(peak.startIndex, 10)
        XCTAssertLessThanOrEqual(peak.endIndex, 20)
        XCTAssertTrue((peak.startIndex...peak.endIndex).contains(peak.markerIndex))
        XCTAssertEqual(points[peak.endIndex].timestamp.timeIntervalSince(points[peak.startIndex].timestamp), 5)
    }
    func testPeakRequiresFiveSecondsAndKnownTimestamps() {
        XCTAssertNil(TourStats(points: speedPoints(Array(repeating: 72, count: 4))).maximumSpeed)
        let points = speedPoints(Array(repeating: 72, count: 12)).map { point -> TrackPoint in
            var result = point; result.timestampKnown = false; return result
        }
        XCTAssertNil(TourStats(points: points).maximumSpeedWindow)
        XCTAssertEqual(TourStats(points: speedPoints(Array(repeating: 0, count: 10))).maximumSpeed, 0)
    }
    func testPeakDoesNotBridgePausesOrTimeGaps() {
        var points = speedPoints(Array(repeating: 72, count: 8))
        points[4].segmentStart = true
        XCTAssertNil(TourStats(points: points).maximumSpeed)
        points[4].segmentStart = false
        for index in 4..<points.count { points[index].timestamp.addTimeInterval(20) }
        XCTAssertNil(TourStats(points: points).maximumSpeed)
        XCTAssertNil(TourStats(points: speedPoints(Array(repeating: 72, count: 10), interval: 16)).maximumSpeed)
    }
    func testGPSJumpDoesNotCreatePeak() {
        var points = speedPoints(Array(repeating: 36, count: 12))
        points.insert(point(64, seconds: 6.5), at: 7)
        XCTAssertEqual(TourStats(points: points).maximumSpeed ?? -1, 36, accuracy: 0.01)
        let inaccurate = points.map { point -> TrackPoint in var result = point; result.accuracy = 100; return result }
        XCTAssertNil(TourStats(points: inaccurate).maximumSpeedWindow)
    }
    func testNonIncreasingTimesCannotCreatePeak() {
        let points = speedPoints(Array(repeating: 72, count: 12)).map { point -> TrackPoint in
            var result = point; result.timestamp = Date(timeIntervalSince1970: 1); return result
        }
        XCTAssertNil(TourStats(points: points).maximumSpeed)
    }
    func testDescentAndRangeForSnowboarding() throws {
        let points = (0..<81).map { point(62 + Double($0) * 0.0001, altitude: 1_000 - Double($0) * 10) }
        let stats = TourStats(points: points)
        XCTAssertEqual(stats.ascent, 0)
        XCTAssertGreaterThan(try XCTUnwrap(stats.descent), 760)
        XCTAssertEqual(try XCTUnwrap(stats.elevationRange), try XCTUnwrap(stats.maximum) - XCTUnwrap(stats.minimum), accuracy: 0.001)
        XCTAssertEqual(Display.descent(12), Display.number(-12))
        XCTAssertEqual(Display.descent(0), Display.number(0))
        XCTAssertEqual(Display.descent(nil), "—")
    }
    func testLiftDoesNotCancelRepeatedDescents() throws {
        let down = (0..<51).map { 1_000.0 - Double($0) * 10 }
        let up = (0..<51).map { 500.0 + Double($0) * 10 }
        let altitudes = down + Array(repeating: 500, count: 15) + up + Array(repeating: 1_000, count: 15) + down + Array(repeating: 500, count: 15)
        let points = altitudes.enumerated().map { point(62 + Double($0.offset) * 0.0001, altitude: $0.element) }
        let stats = TourStats(points: points)
        XCTAssertGreaterThan(try XCTUnwrap(stats.descent), 980)
        XCTAssertLessThanOrEqual(try XCTUnwrap(stats.elevationRange), 500)
    }
    func testNoInventedElevationRange() {
        XCTAssertNil(TourStats(points: []).elevationRange)
        XCTAssertNil(TourStats(points: [point(62, altitude: 500)]).elevationRange)
        XCTAssertEqual(TourStats(points: [point(62, altitude: 0), point(62.001, altitude: 0)]).elevationRange, 0)
    }
    func testGPXPreservesFractionalTimestamps() throws {
        let tour = Tour(name: "Sekunder", points: [point(62, seconds: 1.125, start: true), point(62.001, seconds: 6.625)])
        let url = try GPX.export(tour)
        defer { try? FileManager.default.removeItem(at: url) }
        let restored = try GPX.read(url)
        XCTAssertEqual(restored.points[0].timestamp.timeIntervalSince1970, 1.125, accuracy: 0.001)
        XCTAssertEqual(restored.points[1].timestamp.timeIntervalSince1970, 6.625, accuracy: 0.001)
    }

}
