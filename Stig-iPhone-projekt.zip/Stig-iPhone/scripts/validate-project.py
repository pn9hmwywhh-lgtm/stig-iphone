"""Portable structural checks; these do not replace Xcode compilation/tests."""
import json
import plistlib
import re
import struct
from pathlib import Path
from xml.etree import ElementTree

root = Path(__file__).resolve().parent.parent
project = root / 'Stig.xcodeproj/project.pbxproj'
text = project.read_text()
declared = set(re.findall(r'^\s*([A-F0-9]{24})\s*=', text, re.MULTILINE))
references = set(re.findall(r'\b[A-F0-9]{24}\b', text))
assert references <= declared, f'Okända projektreferenser: {references - declared}'
for source in (root / 'Stig').glob('*.swift'):
    assert f'path = {source.name};' in text, f'{source.name} saknas i Xcode-projektet'
assert 'path = ModelTests.swift;' in text
with (root / 'Stig/Info.plist').open('rb') as file:
    info = plistlib.load(file)
assert info['UIBackgroundModes'] == ['location']
assert info['NSLocationWhenInUseUsageDescription']
assert info['NSLocationTemporaryUsageDescriptionDictionary']['HikeRecording']
assert 'IPHONEOS_DEPLOYMENT_TARGET = 17.0;' in text
scheme = ElementTree.parse(root / 'Stig.xcodeproj/xcshareddata/xcschemes/Stig.xcscheme')
for target in scheme.iter('BuildableReference'):
    assert target.attrib['BlueprintIdentifier'] in declared
icon_root = root / 'Stig/Assets.xcassets/AppIcon.appiconset'
icons = json.loads((icon_root / 'Contents.json').read_text())
for entry in icons['images']:
    if 'filename' in entry:
        image = (icon_root / entry['filename']).read_bytes()
        assert image[:8] == b'\x89PNG\r\n\x1a\n'
        assert struct.unpack('>II', image[16:24]) == (1024, 1024)
assert (root / '.github/workflows/build-iphone.yml').is_file()
print('Godkänt: projektfiler, referenser, schema, bakgrundsläge och appikon.')
