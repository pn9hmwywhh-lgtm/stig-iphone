# Stig för iPhone

En personlig turdagbok för vandring, snowboard, skidåkning, SUP, cykling och löpning. Kräver **iOS 17 eller senare**. Inga externa Swift-paket, API-nycklar eller betalabonnemang behövs.

**Börja med [INSTALLERA-WINDOWS.md](INSTALLERA-WINDOWS.md).** Där finns vägen från Windows till GitHub-bygge och SideStore på telefonen.

Version 0.2.0 innehåller GPS-inspelning med bakgrundsläge, topografisk karta, sparade turer, GPX-import/export, distans, aktiv tid, stigning, negativa höjdmeter, fallhöjd, höjdprofil och maxhastighet med markör och mätsträcka på kartan.

**Byggstatus:** källkod och GitHub-flöde är förberedda och strukturellt kontrollerade. Ingen IPA har byggts i den här Linux-miljön. Första kompileringen och modelltestkörningen sker när flödet körs hos GitHub. GPS med låst skärm måste sedan provas på din fysiska iPhone. Se [VALIDERING.md](VALIDERING.md).

## Bygga hos GitHub

Lägg mappens innehåll i roten av ett publikt GitHub-repo. Flödet **Bygg Stig för iPhone** körs vid relevanta ändringar på `main` eller manuellt under **Actions → Run workflow**. Det använder en standardrunner med macOS, kör modelltesterna på Mac och skapar en osignerad `Stig.ipa`. Artefakten **Stig-iPhone** innehåller appfilen. SideStore signerar den sedan med ditt eget kostnadsfria Apple-konto.

Byggflödet är spärrat för privata repo för att undvika debiterad byggtid. Ingen Apple-inloggning, certifikat eller privata turdata behövs hos GitHub. Att lägga upp källkod innebär inte att dina turer publiceras; de sparas på telefonen.

## Bygga på egen Mac

Öppna `Stig.xcodeproj` i Xcode. Välj schemat **Stig** och en iPhone-simulator för tester. För direkt installation väljer du din egen Team under Signing & Capabilities och använder ett unikt Bundle Identifier. Alternativt kör:

```bash
bash scripts/test-ios.sh
bash scripts/build-ipa.sh
```

Det andra kommandot skapar `build/Stig.ipa` för sideloading, utan signeringsuppgifter. Direkt installation från Xcode kräver din egen Apple-identitet; SideStore kan signera IPA-filen i efterhand.

## Bakgrundsinspelning och data

Starta turen med Stig öppen. Appen behåller både `CLLocationManager` och `CLBackgroundActivitySession`, aktiverar platsuppdateringar i bakgrunden och visar iOS platsindikator. `UIBackgroundModes` innehåller `location`. Exakt plats och When In Use-behörighet begärs när turen startas. Paus och avslut stoppar uppdateringarna och avslutar bakgrundssessionen.

GPS-uppdateringar sparar utkastet löpande, även när en vanlig UI-timer inte körs. Filen skrivs atomiskt med `completeUntilFirstUserAuthentication` så att lagring är möjlig efter låsning. Utkast återställs alltid pausade vid en ny start. Befintlig oläsbar lagring skrivs inte över med en tom databas.

Svep inte bort Stig ur appväxlaren under inspelning. Kontrollera en kort tur med låst skärm innan du använder appen på en längre tur. Tvångsavslut och systemavslut kan avbryta inspelningen; appen lovar inte automatisk återstart.

Turer lagras lokalt i iPhone-appen och synkas inte automatiskt med webbversionen. Exportera GPX för säkerhetskopior och överföring mellan appar. GPX behåller segment, tidsstämplar med millisekunder, aktivitet och aktiv tid. Saknad tid eller höjd hittas inte på.

## Värden och karta

Nedför visas med minustecken och summerar alla nedförsdelar; lift upp dras inte av. Fallhöjd är högsta minus lägsta utjämnade GPS-höjd. Utjämning och 4 m tröskel begränsar höjdbrus.

Maxhastighet är högsta GPS-snitt över minst fem sekunder. Punkter med osäkerhet över 50 m, ogiltiga tider, luckor över 15 sekunder och hopp över 45 m/s tas inte med i hastighetsfönstret. Pauser bryter fönstret. Den mörkorange sträckan och markören visar var värdet mättes. Markören ligger vid en GPS-punkt mitt i mätsträckan, inte vid en exakt momentan toppfart. Samma beräkning används för gamla och importerade turer. Saknas tillräckligt täta tidsstämplar visas ett streck.

Distans och höjd kopplas inte ihop över pauser eller signalluckor över 90 sekunder. Aktiv tid inkluderar stillastående fram till manuell paus.

Topografisk karta: © OpenStreetMap, SRTM; kartstil © OpenTopoMap, CC BY-SA 3.0. Standardkartan använder Apple Maps. Kartleverantörerna får de kartutsnitt du visar. Nya utsnitt kräver internet; kompletta offlinekartor ingår inte.

## Tester utan simulator

`swift test --scratch-path build/model-tests` kör modell- och GPX-testerna direkt på macOS mot samma två källfiler som används i appen. CI använder detta för att undvika simulatorns startberoende. Hela iPhone-appen kompileras sedan mot iOS SDK när IPA-filen byggs. Xcode-simulatorns tester finns kvar som ett separat manuellt alternativ via `scripts/test-ios.sh`.
