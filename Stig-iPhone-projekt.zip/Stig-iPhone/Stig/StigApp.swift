import SwiftUI

@main
struct StigApp: App {
    @StateObject private var recorder = Recorder()
    @Environment(\.scenePhase) private var scenePhase
    var body: some Scene {
        WindowGroup {
            ContentView().environmentObject(recorder)
                .tint(.pine).preferredColorScheme(.light)
                .environment(\.locale, Locale(identifier: "sv_SE"))
                .onChange(of: scenePhase) { _, phase in
                    if phase == .background { recorder.checkpoint(force: true) }
                }
        }
    }
}
