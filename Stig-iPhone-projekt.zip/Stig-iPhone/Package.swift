// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "StigModelTests",
    platforms: [.macOS(.v13), .iOS(.v17)],
    products: [.library(name: "Stig", targets: ["Stig"])],
    targets: [
        .target(name: "Stig", path: "Stig",
            exclude: ["ContentView.swift", "DiskStore.swift", "Recorder.swift", "StigApp.swift", "TopoMap.swift", "Info.plist", "Assets.xcassets"],
            sources: ["Models.swift", "GPX.swift"]),
        .testTarget(name: "StigTests", dependencies: ["Stig"], path: "Tests")
    ]
)
