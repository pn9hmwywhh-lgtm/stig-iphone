import SwiftUI
import MapKit

struct TopoMap: UIViewRepresentable {
    var tour: Tour?
    var location: CLLocation? = nil
    var topographic: Bool
    var fitToken: Int
    var peakFitToken = 0
    @Binding var follow: Bool

    func makeCoordinator() -> Coordinator { Coordinator() }
    func makeUIView(context: Context) -> MKMapView {
        let map = MKMapView()
        map.delegate = context.coordinator
        map.showsCompass = true; map.showsScale = true
        map.pointOfInterestFilter = .excludingAll
        map.cameraZoomRange = MKMapView.CameraZoomRange(minCenterCoordinateDistance: 400)
        map.setRegion(MKCoordinateRegion(center: CLLocationCoordinate2D(latitude: 62.391, longitude: 17.306),
            span: MKCoordinateSpan(latitudeDelta: 0.06, longitudeDelta: 0.06)), animated: false)
        return map
    }

    func updateUIView(_ map: MKMapView, context: Context) {
        let coordinator = context.coordinator
        coordinator.onPan = { follow = false }
        if coordinator.topographic != topographic {
            if let tile = coordinator.tile { map.removeOverlay(tile) }
            if topographic {
                let tile = MKTileOverlay(urlTemplate: "https://a.tile.opentopomap.org/{z}/{x}/{y}.png")
                tile.minimumZ = 3; tile.maximumZ = 17; tile.canReplaceMapContent = true
                map.insertOverlay(tile, at: 0, level: .aboveLabels); coordinator.tile = tile
            } else { coordinator.tile = nil }
            coordinator.topographic = topographic
        }
        if coordinator.tourID != tour?.id || coordinator.pointCount != tour?.points.count {
            map.removeOverlays(map.overlays.filter { $0 is MKPolyline })
            map.removeAnnotations(map.annotations)
            coordinator.peakAnnotation = nil
            coordinator.peakPoints = []
            for group in tour?.segments ?? [] where group.count > 1 {
                let coordinates = group.map { CLLocationCoordinate2D(latitude: $0.latitude, longitude: $0.longitude) }
                let border = MKPolyline(coordinates: coordinates, count: coordinates.count); border.title = "border"
                let line = MKPolyline(coordinates: coordinates, count: coordinates.count)
                map.addOverlay(border, level: .aboveLabels); map.addOverlay(line, level: .aboveLabels)
            }
            if let first = tour?.points.first {
                let annotation = MKPointAnnotation(); annotation.title = "Start"
                annotation.coordinate = coordinate(first)
                map.addAnnotation(annotation)
            }
            if let last = tour?.points.last, (tour?.points.count ?? 0) > 1 {
                let annotation = MKPointAnnotation(); annotation.title = "Senaste spårpunkt"
                annotation.coordinate = coordinate(last)
                map.addAnnotation(annotation)
            }
            if let tour, let peak = tour.stats.maximumSpeedWindow, peak.kilometersPerHour > 0 {
                let section = Array(tour.points[peak.startIndex...peak.endIndex])
                let coordinates = section.map(coordinate)
                let line = MKPolyline(coordinates: coordinates, count: coordinates.count); line.title = "peak"
                map.addOverlay(line, level: .aboveLabels)
                let annotation = PeakAnnotation()
                annotation.title = "Max \(Display.number(peak.kilometersPerHour, digits: 1)) km/h"
                let seconds = tour.points[peak.endIndex].timestamp.timeIntervalSince(tour.points[peak.startIndex].timestamp)
                annotation.subtitle = "GPS-snitt över \(Display.number(seconds, digits: 1)) s · markerad sträcka"
                annotation.coordinate = coordinate(tour.points[peak.markerIndex])
                map.addAnnotation(annotation)
                coordinator.peakAnnotation = annotation
                coordinator.peakPoints = section
            }
            coordinator.tourID = tour?.id; coordinator.pointCount = tour?.points.count
        }
        if coordinator.peakFitToken != peakFitToken, peakFitToken > 0, !coordinator.peakPoints.isEmpty {
            fit(coordinator.peakPoints, on: map)
            if let annotation = coordinator.peakAnnotation { map.selectAnnotation(annotation, animated: false) }
        } else if follow, let location {
            map.setRegion(MKCoordinateRegion(center: location.coordinate,
                span: MKCoordinateSpan(latitudeDelta: 0.009, longitudeDelta: 0.009)), animated: false)
        } else if coordinator.fitToken != fitToken, let points = tour?.points, !points.isEmpty {
            fit(points, on: map)
        }
        coordinator.fitToken = fitToken
        coordinator.peakFitToken = peakFitToken
    }

    private func coordinate(_ point: TrackPoint) -> CLLocationCoordinate2D {
        CLLocationCoordinate2D(latitude: point.latitude, longitude: point.longitude)
    }

    private func fit(_ points: [TrackPoint], on map: MKMapView) {
        guard !points.isEmpty else { return }
        let rect = points.reduce(MKMapRect.null) { result, point in
            let value = MKMapPoint(coordinate(point))
            return result.union(MKMapRect(x: value.x, y: value.y, width: 1, height: 1))
        }
        map.setVisibleMapRect(rect.insetBy(dx: -500, dy: -500),
            edgePadding: UIEdgeInsets(top: 65, left: 45, bottom: 55, right: 45), animated: false)
    }

    final class PeakAnnotation: MKPointAnnotation { }

    final class Coordinator: NSObject, MKMapViewDelegate {
        var tile: MKTileOverlay?, topographic: Bool?, tourID: UUID?, pointCount: Int?, fitToken: Int?, peakFitToken: Int?
        var peakAnnotation: PeakAnnotation?
        var peakPoints: [TrackPoint] = []
        var onPan: (() -> Void)?
        func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
            if let tile = overlay as? MKTileOverlay { return MKTileOverlayRenderer(tileOverlay: tile) }
            if let line = overlay as? MKPolyline {
                let renderer = MKPolylineRenderer(polyline: line)
                switch line.title {
                case "border": renderer.strokeColor = .white; renderer.lineWidth = 8
                case "peak": renderer.strokeColor = UIColor(red: 0.65, green: 0.28, blue: 0.13, alpha: 1); renderer.lineWidth = 8
                default: renderer.strokeColor = UIColor(red: 0.89, green: 0.46, blue: 0.27, alpha: 1); renderer.lineWidth = 4
                }
                renderer.lineCap = .round; renderer.lineJoin = .round
                return renderer
            }
            return MKOverlayRenderer(overlay: overlay)
        }
        func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
            let view = MKMarkerAnnotationView(annotation: annotation, reuseIdentifier: nil)
            if annotation is PeakAnnotation {
                view.markerTintColor = UIColor(red: 0.65, green: 0.28, blue: 0.13, alpha: 1)
                view.glyphImage = UIImage(systemName: "speedometer")
                view.titleVisibility = .visible
                view.displayPriority = .required
            } else {
                view.markerTintColor = annotation.title == "Start" ? UIColor(Color.pine) : .systemOrange
                view.glyphImage = UIImage(systemName: annotation.title == "Start" ? "flag.fill" : "figure.hiking")
            }
            view.canShowCallout = true
            return view
        }
        func mapView(_ mapView: MKMapView, regionWillChangeAnimated animated: Bool) {
            var userGesture = false
            for subview in mapView.subviews {
                for gesture in subview.gestureRecognizers ?? [] {
                    if gesture.state == .began || gesture.state == .changed { userGesture = true }
                }
            }
            if userGesture { DispatchQueue.main.async { self.onPan?() } }
        }
    }
}
