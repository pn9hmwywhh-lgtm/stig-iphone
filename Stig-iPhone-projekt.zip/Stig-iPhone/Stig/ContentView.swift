import SwiftUI
import Charts
import UniformTypeIdentifiers

extension Color {
    static let pine = Color(red: 0.09, green: 0.29, blue: 0.24)
    static let canvas = Color(red: 0.95, green: 0.97, blue: 0.95)
}

struct ContentView: View {
    @EnvironmentObject private var recorder: Recorder
    var body: some View {
        TabView {
            NavigationStack { RecordingView() }.tabItem { Label("Spela in", systemImage: "map") }
            NavigationStack { ToursView() }.tabItem { Label("Mina turer", systemImage: "point.topleft.down.to.point.bottomright.curvepath") }
            NavigationStack { AboutView() }.tabItem { Label("Om Stig", systemImage: "info.circle") }
        }
        .alert("Stig", isPresented: Binding(get: { recorder.message != nil }, set: { if !$0 { recorder.message = nil } })) {
            Button("OK", role: .cancel) { recorder.message = nil }
        } message: { Text(recorder.message ?? "") }
    }
}

struct RecordingView: View {
    @EnvironmentObject private var recorder: Recorder
    @State private var activity = Activity.hiking
    @State private var topographic = true
    @State private var follow = true
    @State private var fitToken = 0
    @State private var peakFitToken = 0
    @State private var showSave = false
    @State private var confirmDiscard = false
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                VStack(alignment: .leading, spacing: 7) {
                    Text("MER UTE. MER DU.").font(.caption.weight(.semibold)).tracking(1.6).foregroundStyle(Color.pine)
                    Text("Följ ditt eget spår.").font(.largeTitle.bold()).tracking(-1)
                    Text("Din tur. Din takt. Första steget börjar här.").foregroundStyle(.secondary)
                }
                if let error = recorder.persistenceError {
                    Label(error, systemImage: "exclamationmark.triangle").font(.callout).padding()
                        .background(.orange.opacity(0.12), in: RoundedRectangle(cornerRadius: 12))
                }
                StatsGrid(stats: recorder.draft?.stats ?? TourStats(points: []), duration: recorder.duration)
                VStack(alignment: .leading, spacing: 0) {
                    HStack {
                        Label(topographic ? "Topografisk karta" : "Standardkarta", systemImage: "mountain.2")
                            .font(.headline)
                        Spacer()
                        Button { topographic.toggle() } label: { Image(systemName: "square.3.layers.3d") }
                            .accessibilityLabel("Byt mellan topografisk karta och standardkarta")
                    }.padding()
                    TopoMap(tour: recorder.draft, location: recorder.latest, topographic: topographic,
                        fitToken: fitToken, peakFitToken: peakFitToken, follow: $follow).frame(height: 330)
                        .overlay(alignment: .bottomTrailing) {
                            VStack(spacing: 12) {
                                Button { follow = true } label: { Image(systemName: "location.fill") }
                                    .accessibilityLabel("Följ min position")
                                Button { follow = false; fitToken += 1 } label: { Image(systemName: "arrow.up.left.and.arrow.down.right") }
                                    .accessibilityLabel("Visa hela turen")
                            }.font(.title3).padding(12).background(.regularMaterial, in: RoundedRectangle(cornerRadius: 12)).padding()
                        }
                    if (recorder.draft?.stats.maximumSpeed ?? 0) > 0 {
                        Button { follow = false; peakFitToken += 1 } label: { Label("Visa toppfarten", systemImage: "speedometer") }.padding(.top, 10)
                    }
                    Attribution(topographic: topographic)
                }.background(.white, in: RoundedRectangle(cornerRadius: 16)).clipShape(RoundedRectangle(cornerRadius: 16))
                ElevationProfile(stats: recorder.draft?.stats ?? TourStats(points: []))
                VStack(alignment: .leading, spacing: 14) {
                    HStack { Text("Din aktivitet").font(.headline); Spacer();
                        Picker("Aktivitet", selection: $activity) {
                            ForEach(Activity.allCases) { value in Label(value.rawValue, systemImage: value.symbol).tag(value) }
                        }.disabled(recorder.draft != nil)
                    }
                    Label(recorder.signal, systemImage: "location.circle").font(.callout).foregroundStyle(.secondary)
                    Label("Starta turen medan appen är öppen. Inspelningen är konfigurerad för att fortsätta med låst skärm.", systemImage: "lock.iphone")
                        .font(.callout).foregroundStyle(.secondary)
                    if recorder.draft?.hasGaps == true {
                        Text("Spåret innehåller GPS-luckor. Sträckan genom luckorna räknas inte.").font(.callout).foregroundStyle(.orange)
                    }
                }.padding().background(.white, in: RoundedRectangle(cornerRadius: 16))
                Text("Ta bara minnen. Lämna bara fotspår.").font(.footnote).foregroundStyle(.secondary).frame(maxWidth: .infinity).padding(.vertical)
            }.padding()
        }
        .background(Color.canvas)
        .navigationTitle("stig.").navigationBarTitleDisplayMode(.inline)
        .safeAreaInset(edge: .bottom) {
            HStack(spacing: 12) {
                VStack(alignment: .leading, spacing: 4) {
                    Text(recorder.status).font(.caption).foregroundStyle(.secondary)
                    Text(Display.clock(recorder.duration)).font(.headline.monospacedDigit())
                }
                Spacer(minLength: 4)
                Button {
                    if recorder.isActive { recorder.pause() }
                    else { follow = true; recorder.start(activity: recorder.draft?.activity ?? activity) }
                } label: {
                    Label(recorder.phase == .recording ? "Pausa" : recorder.phase == .waiting ? "Avbryt" : recorder.phase == .paused ? "Fortsätt" : "Starta tur",
                        systemImage: recorder.isActive ? "pause.fill" : "record.circle")
                }.buttonStyle(.borderedProminent).disabled(recorder.isSaving)
                if recorder.draft != nil {
                    Button {
                        recorder.pause()
                        if recorder.draft?.points.isEmpty == true { confirmDiscard = true } else { showSave = true }
                    } label: { Image(systemName: "stop.fill") }.buttonStyle(.bordered)
                        .accessibilityLabel("Avsluta och spara turen").disabled(recorder.isSaving)
                }
            }.padding().background(.regularMaterial)
        }
        .sheet(isPresented: $showSave) { SaveTourView() }
        .confirmationDialog("Avsluta utan spår?", isPresented: $confirmDiscard, titleVisibility: .visible) {
            Button("Avsluta inspelningen", role: .destructive) { Task { await recorder.discard() } }
            Button("Avbryt", role: .cancel) { }
        } message: { Text("Ingen GPS-position har spelats in ännu.") }
    }
}

struct StatsGrid: View {
    let stats: TourStats
    let duration: TimeInterval
    var body: some View {
        LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 12) {
            metric("Distans", value: Display.number(stats.distance / 1_000, digits: 2), unit: "km", icon: "point.topleft.down.to.point.bottomright.curvepath")
            metric("Nedför", value: Display.descent(stats.descent), unit: "m", icon: "arrow.down.right")
            metric("Fallhöjd", value: Display.number(stats.elevationRange), unit: "m", icon: "arrow.up.and.down")
            metric("Stigning", value: Display.number(stats.ascent), unit: "m", icon: "arrow.up.right")
            metric("Aktiv tid", value: Display.clock(duration), unit: "", icon: "clock")
            metric("Maxhastighet", value: Display.number(stats.maximumSpeed, digits: 1), unit: "km/h", icon: "speedometer")
        }
        Text("Snittfart \(Display.number(duration > 0 ? stats.distance / 1_000 / (duration / 3_600) : nil, digits: 1)) km/h · Toppfart är ett GPS-snitt över minst 5 sekunder.")
            .font(.footnote).foregroundStyle(.secondary)
    }
    private func metric(_ title: String, value: String, unit: String, icon: String) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack { Text(title).font(.subheadline).foregroundStyle(.secondary); Spacer(); Image(systemName: icon).foregroundStyle(Color.pine.opacity(0.6)) }
            HStack(alignment: .firstTextBaseline, spacing: 4) {
                Text(value).font(.system(size: 25, weight: .semibold, design: .rounded)).monospacedDigit().minimumScaleFactor(0.7).lineLimit(1)
                Text(unit).font(.caption).foregroundStyle(.secondary)
            }
        }.padding().frame(maxWidth: .infinity, alignment: .leading).background(.white, in: RoundedRectangle(cornerRadius: 14))
    }
}

struct ElevationProfile: View {
    let stats: TourStats
    private var samples: [HeightSample] {
        let stride = max(1, stats.profile.count / 400)
        return stats.profile.enumerated().filter { index, value in
            index % stride == 0 || index == stats.profile.count - 1 || index == 0 || value.segment != stats.profile[index - 1].segment
        }.map(\.element)
    }
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack { Label("Höjdprofil", systemImage: "mountain.2").font(.headline); Spacer(); Text("Utjämnad höjd").font(.caption).foregroundStyle(.secondary) }
            if stats.profile.count > 1 {
                Chart(samples) { sample in
                    LineMark(x: .value("Distans, km", sample.kilometers), y: .value("Höjd, m", sample.altitude),
                        series: .value("Segment", sample.segment))
                        .foregroundStyle(Color.pine).lineStyle(StrokeStyle(lineWidth: 2))
                }.chartYScale(domain: ((stats.minimum ?? 0) - 10)...((stats.maximum ?? 0) + 10))
                    .chartXAxisLabel("km").chartYAxisLabel("m").frame(height: 135)
            } else {
                Text("Höjdprofilen växer fram när GPS:en levererar höjddata.")
                    .font(.callout).foregroundStyle(.secondary).frame(maxWidth: .infinity, minHeight: 100)
            }
            HStack {
                Text("Nedför \(Display.descent(stats.descent)) m")
                Spacer()
                Text("Högsta \(Display.number(stats.maximum)) m")
            }.font(.footnote).foregroundStyle(.secondary)
        }.padding().background(.white, in: RoundedRectangle(cornerRadius: 16))
    }
}

struct Attribution: View {
    var topographic = true
    var body: some View {
        VStack(alignment: .leading, spacing: 3) {
            if topographic {
                Text("© [OpenStreetMap](https://www.openstreetmap.org/copyright), SRTM · [OpenTopoMap](https://opentopomap.org/about) ([CC BY-SA](https://creativecommons.org/licenses/by-sa/3.0/))")
                Text("Nya kartutsnitt kräver internet. Byt kartlager om bakgrunden inte laddas.").foregroundStyle(.secondary)
            } else { Text("Standardkarta: Apple Maps") }
        }.font(.caption2).padding(10).frame(maxWidth: .infinity, alignment: .leading)
    }
}

struct SaveTourView: View {
    @EnvironmentObject private var recorder: Recorder
    @Environment(\.dismiss) private var dismiss
    @State private var name = ""
    @State private var notes = ""
    @State private var discard = false
    @State private var shareURL: URL?
    var body: some View {
        NavigationStack {
            Form {
                Section("Ett nytt minne att spara") {
                    TextField("Ge turen ett namn", text: $name).textInputAutocapitalization(.sentences)
                    TextField("Anteckning (valfritt)", text: $notes, axis: .vertical).lineLimit(3...6)
                }
                if let draft = recorder.draft {
                    Section {
                        Label("\(Display.number(draft.stats.distance / 1_000, digits: 2)) km", systemImage: "map")
                        Label(Display.clock(recorder.duration), systemImage: "clock")
                        if let shareURL { ShareLink(item: shareURL) { Label("GPX som säkerhetskopia", systemImage: "square.and.arrow.up") } }
                    }
                }
                Section {
                    Button("Spara turen") { Task { if await recorder.save(name: name, notes: notes) { dismiss() } } }
                        .disabled(recorder.isSaving || recorder.draft?.points.isEmpty != false)
                    Button("Kasta inspelningen", role: .destructive) { discard = true }.disabled(recorder.isSaving)
                }
            }
            .navigationTitle("Väl tillbaka").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .cancellationAction) { Button("Stäng") { dismiss() }.disabled(recorder.isSaving) } }
            .onAppear {
                if let draft = recorder.draft {
                    name = draft.name; notes = draft.notes
                    do { shareURL = try GPX.export(draft) } catch { recorder.message = "GPX-filen kunde inte skapas." }
                }
            }
            .confirmationDialog("Kasta inspelningen?", isPresented: $discard, titleVisibility: .visible) {
                Button("Kasta inspelningen", role: .destructive) { Task { await recorder.discard(); if recorder.draft == nil { dismiss() } } }
            } message: { Text("Spårpunkterna i den här inspelningen tas bort från appen.") }
        }.interactiveDismissDisabled(recorder.isSaving)
    }
}

struct ToursView: View {
    @EnvironmentObject private var recorder: Recorder
    @State private var importing = false
    @State private var query = ""
    @State private var deletion: Tour?
    private var filtered: [Tour] {
        recorder.tours.filter { query.isEmpty || ($0.title + " " + $0.activity.rawValue + " " + $0.notes).localizedCaseInsensitiveContains(query) }
    }
    var body: some View {
        List {
            if filtered.isEmpty {
                ContentUnavailableView(query.isEmpty ? "Här finns plats för äventyr" : "Inga turer hittades", systemImage: "figure.hiking",
                    description: Text("Spela in din första tur eller importera en GPX-fil."))
            }
            ForEach(filtered) { tour in
                NavigationLink { TourDetailView(tour: tour) } label: {
                    VStack(alignment: .leading, spacing: 7) {
                        Label(tour.title, systemImage: tour.activity.symbol).font(.headline)
                        Text("\(tour.createdAt.formatted(date: .abbreviated, time: .omitted)) · \(Display.number(tour.stats.distance / 1_000, digits: 2)) km · \(Display.descent(tour.stats.descent)) m nedför")
                            .font(.footnote).foregroundStyle(.secondary)
                        Text("Max \(Display.number(tour.stats.maximumSpeed, digits: 1)) km/h · Fallhöjd \(Display.number(tour.stats.elevationRange)) m").font(.footnote).foregroundStyle(.secondary)
                    }.padding(.vertical, 5)
                }
                .swipeActions { Button("Ta bort", role: .destructive) { deletion = tour } }
            }
        }
        .navigationTitle("Mina turer").searchable(text: $query, prompt: "Sök bland dina turer")
        .toolbar { Button { importing = true } label: { Label("Importera GPX", systemImage: "square.and.arrow.down") }.disabled(recorder.isSaving) }
        .fileImporter(isPresented: $importing, allowedContentTypes: [UTType(filenameExtension: "gpx") ?? .xml, .xml]) { result in
            do {
                let tour = try GPX.read(result.get())
                Task { await recorder.importTour(tour) }
            } catch { recorder.message = error.localizedDescription }
        }
        .confirmationDialog("Ta bort turen?", isPresented: Binding(get: { deletion != nil }, set: { if !$0 { deletion = nil } }), titleVisibility: .visible) {
            if let tour = deletion { Button("Ta bort \(tour.title)", role: .destructive) { deletion = nil; Task { await recorder.deleteTour(id: tour.id) } } }
            Button("Avbryt", role: .cancel) { deletion = nil }
        } message: { Text("Turen tas bort från appen. En exporterad GPX-fil påverkas inte.") }
    }
}

struct TourDetailView: View {
    let tour: Tour
    @State private var follow = false
    @State private var topographic = true
    @State private var shareURL: URL?
    @State private var exportError: String?
    @State private var peakFitToken = 0
    var body: some View {
        ScrollView {
            VStack(spacing: 18) {
                StatsGrid(stats: tour.stats, duration: tour.duration)
                VStack(spacing: 0) {
                    TopoMap(tour: tour, topographic: topographic, fitToken: 0, peakFitToken: peakFitToken, follow: $follow).frame(height: 360)
                    Attribution(topographic: topographic)
                }.background(.white, in: RoundedRectangle(cornerRadius: 16)).clipShape(RoundedRectangle(cornerRadius: 16))
                if (tour.stats.maximumSpeed ?? 0) > 0 {
                    Button { follow = false; peakFitToken += 1 } label: { Label("Visa toppfarten", systemImage: "speedometer") }.buttonStyle(.bordered)
                }
                Toggle("Topografisk karta", isOn: $topographic).padding().background(.white, in: RoundedRectangle(cornerRadius: 12))
                ElevationProfile(stats: tour.stats)
                if !tour.notes.isEmpty { Text(tour.notes).frame(maxWidth: .infinity, alignment: .leading).padding().background(.white, in: RoundedRectangle(cornerRadius: 12)) }
                if let shareURL { ShareLink(item: shareURL) { Label("Exportera GPX", systemImage: "square.and.arrow.up").frame(maxWidth: .infinity) }.buttonStyle(.borderedProminent) }
                if let exportError { Text(exportError).foregroundStyle(.red) }
                if tour.imported && tour.duration == 0 { Text("GPX-filen saknade uppgifter om tid.").font(.footnote).foregroundStyle(.secondary) }
            }.padding()
        }.background(Color.canvas).navigationTitle(tour.title).navigationBarTitleDisplayMode(.inline)
            .onAppear { do { shareURL = try GPX.export(tour) } catch { exportError = "GPX-filen kunde inte skapas." } }
    }
}

struct AboutView: View {
    var body: some View {
        List {
            Section("Ut på tur med iPhone") {
                Text("Starta inspelningen med Stig öppen och tillåt Exakt plats. iOS visar en platsindikator när turen spelas in i bakgrunden.")
                Text("Du kan låsa skärmen. Svep inte bort Stig från appväxlaren under inspelningen. Efter en omstart eller om appen avslutats återställs utkastet pausat; inspelningen återstartar inte själv.")
                Button("Öppna Stigs inställningar") { if let url = URL(string: UIApplication.openSettingsURLString) { UIApplication.shared.open(url) } }
            }
            Section("Dina turer är dina") {
                Text("Turer sparas lokalt i den här appen. Det finns ingen automatisk synk med webbappen. Exportera GPX för säkerhetskopior och för att flytta turer mellan appar.")
                Text("Kartleverantörer får de kartutsnitt du visar. Nya kartutsnitt kräver internet; någon nedladdning av kompletta offlinekartor ingår inte.")
            }
            Section("Om värdena") {
                Text("Distansen beräknas mellan godkända positioner. Stigning och nedför är utjämnade GPS-uppskattningar. Saknas höjddata visas ett streck. Höjdvärden kan skilja sig från kartan.")
                Text("Nedför är summan av alla nedförsdelar; lift upp dras inte av. Fallhöjd är turens högsta minus lägsta utjämnade höjd. Maxhastigheten är högsta GPS-snitt över minst fem sekunder. Mätsträckan och en markör visas på kartan. Tidsluckor över 15 sekunder räknas bort från hastigheten.")
                Text("Pauser och GPS-luckor över 90 sekunder börjar nya spårsegment. Distans och höjd räknas inte genom luckorna. Aktiv tid inkluderar stillastående tills du trycker på Pausa.")
            }
            Section("Testversion") {
                Text("Det här är en personlig testversion. Prova en kort tur med låst skärm och kontrollera spåret innan en längre tur. Bakgrundsinspelning och batteriförbrukning behöver verifieras på din iPhone.")
                Link("Webbversionen av Stig", destination: URL(string: "https://stig-turdagbok.ymdndcgrhn.chatgpt.site")!)
                Link("OpenTopoMap och kartlicens", destination: URL(string: "https://opentopomap.org/about")!)
            }
        }.navigationTitle("Om Stig")
    }
}
